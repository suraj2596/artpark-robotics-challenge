```bash
catkin build
source ~/catkin_ws/devel/setup.bash
roslaunch cerberus_gazebo washroom_world.launch # launch gazebo with washroom world
rosluanch cerberus_gazebo turtlebot3.launch # spawn turtlebot
roslaunch cerberus_gazebo turtlebot3_navigation.launch # launch rtabmap, navigation stack

rosrun entry_detector main # entry edge detection
```
